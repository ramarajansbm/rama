# ezsploit
![Alt text](https://lh3.googleusercontent.com/yiZeYdV4TwAOYrjdrlyycPDiTWz2CjzkhC7oT-TecNcSRVVFiYC9B3allfR4DzeMAS1uyIQVAC9vR_OzCMaWJLrHm3xw1m_w0A135ebsg8fuZxmIAkP6E1VkewRh3mK59CbDdVCpnE27conw-RVzY-QV8bjFGcWdo3ggPOGd0_K75ISd59FelzSAD2RxkwzdfAfjdI5dFNlVGA_wIiVy73hghXzHJJv_G_M008qe2lqiYhN5dC7Z-hY3WA4PdeYO8TdV1HZzAoqn8tD0_6RgXFWS5d_Um3BUL_J8p8v3QwVZQNX2O00euWaKoQpsT4R5YRkfT-1J1-6_MCnI30xgtAktN-mdJfmSXrPozPdCQuDIZcM99DY1qqH9XSdDYdVk9ppqRFk9clMghaVqj5p-bR-nKZIeJS5FyiQAFXnT0V3jpgqKGJGTcboY6OSPulKvozuK_hx5PFhMl07Q4lVmGpsjO7ZJUUIRoleXSGAEmtjKs_JmE8PUOpj6B5N5Y-ID0-S3SyNRzLvlZBR9DnP2zjzyPhy4eKZY-0pLXiM1njI69bCzux5wlto51PfUdoKJf6JY=w484-h541-no "Main screen")
Linux bash script automation for metasploit
-------------------------------------------

Command line script for automating metasploit functions

- Checks for metasploit service and starts if not present

- Easily craft meterpreter reverse_tcp payloads for Windows, Linux, Android and Mac

- Start multiple meterpreter reverse_tcp listners 

- Assistance with building basic persistence options and scripts

- Armitage launcher 

- Drop into Msfconsole

- Some other fun stuff :)

------------------------------------------
To-Do
Add more functions to payloads/listners, java, php, tomcat etc
Improve overall functionality

Screenshots

![Alt text](https://lh3.googleusercontent.com/2_kIZVLfV37vEOtAzaaCocfgK2R2WhZ3ZG2WGr_KTZlzhxzw80IG2_TGEeG8N-BQXPU3qHHuC8WE3oSlDFD0oidMfv-rejay3dwlK1Dv6gxKlzCERxI1xoiOqQeSZIam3VfCq6ZxElgak47pfJdp1ZxhmfnNH_ELQF2uXQBZSDCdyg_6rLlyUP78HU8MM22PqHQH286R1QYPXJGhA2JJ1n1wQvd5oR7fYkO4yu9Qp5MvxoUcjWKXGtd0PereVdKCm05zBGRrOFj4dTjo-j6gWhBJAy-FGL5Vf8sqjQo7CWlq2GtvqOuoUPTjDXt70eYyg3QFZHae9RFfYrd3YxarNAzrplaP71jn_pW-SrXWo0gfezIOU0YqwhlfaqAfi5nwUyVkhZ1GXWDv5z3HgOWDkZiAKr4SIrUaZVu-AaUNX9vB6rds7hEtiQgQyiznDQPcjCmKi-CcTAbDIvYHWqZki00RnudhQjcBfsRi8VXEFIeXLWyHMWbMT_M7ihTPcKVmHVVDSCSLqi5uivMwHaOHsl4-ZUKj0NlM789scDDd0faqihYbHvcL0P3tKat1SqpRavNf=w484-h541-no "Interactive payload generator")

![Alt text](https://lh3.googleusercontent.com/u_5eZt8J0jyV3lctOYKDej7rwIFZ7Z7szLkYFuPgskYD180cpkjEBSD1T7VdwRHIlX-qlS7w4uaNDv0CcMWIFI82ZTUeFmMyRt2kYMjYO8fPLkMxontDpBeHQax2HJNs_rW_TPpD4ueIyPKvrGcnarAzj9WEcrLUVb0ShkPleGYUfUBBU-gmigT0WtOdLrdiUxMZPb4Xib5Q9nhmX7FlDThhTgrOKlH3l5H2Z-7TRyZ-kSgBBwLJ00W6ooZTuwC4tifTEK2f7fHeLNWz9HmmM0Ic1Tgc5_iCMJgrxXLxTDZQKN8NTFXIfiDoJRaUJP1tWmae9LoVkmLb0T0U0_aiAlaSKFzSE7YqP-jYGdMcVZWOdKCLm3ds1ETy0H0rN92nctXjykgDtn40OiJbE_mr-rgCGzMQfPQEZYSkWienMK63Q5uISCsbkyd0VrTN92ya8Y9sn_msICbpmtoDVV0Oi8fQ3THA0tTkOHgdAoZhSangHcUVjTLvyZT8QKoxGRcemIcqxkakEKIeSk5u6OCZQI3P0R9Zhn2T0TGePcydD3z3wgmXm7VOmzk6bZVKwhwGlnQt=w950-h673-no "Easily start reverse listners")
